package com.visualpathit.account.repository;

import com.visualpathit.account.model.PasswordResetToken;
import com.visualpathit.account.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Long> {
    PasswordResetToken findByToken(String token);
    PasswordResetToken findByUser(User user);
}
