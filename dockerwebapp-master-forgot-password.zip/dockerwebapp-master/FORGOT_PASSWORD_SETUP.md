# Forgot Password feature

## What was added
- Login page `Forgot Password?` link.
- `/forgot-password` page asks for username + registered email.
- 30-minute one-time UUID reset token stored in MySQL.
- `/reset-password?token=...` page changes the password using the existing BCrypt encoder.
- Optional SMTP email delivery.
- CSRF tokens on both POST forms.

## Database
For a brand-new DB image, `Docker-db/db_backup.sql` already creates `password_reset_token`.

For an existing `accounts` database, run:

```bash
mysql -u root -p accounts < forgot_password_migration.sql
```

## Local testing without email
Default:

```properties
MAIL_ENABLED=false
```

Submit the Forgot Password form. The reset URL is written to the Tomcat log as:

```text
MAIL DISABLED - Password reset link for <username>: http://.../reset-password?token=...
```

Open that URL in the browser and set a new password.

## Enable real SMTP email
Do not commit real credentials into source control. Pass them as environment variables.

Example with Gmail SMTP:

```bash
export MAIL_ENABLED=true
export MAIL_HOST=smtp.gmail.com
export MAIL_PORT=587
export MAIL_USERNAME=youraccount@gmail.com
export MAIL_PASSWORD=YOUR_APP_PASSWORD
export MAIL_FROM=youraccount@gmail.com
```

Then rebuild/redeploy the application. Gmail normally requires an App Password for SMTP when 2-Step Verification is enabled.

## Docker Compose
`compose.yml` now forwards the MAIL_* environment variables to the application container.
