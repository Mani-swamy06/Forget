<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password</title>
    <link href="${contextPath}/resources/css/bootstrap.min.css" rel="stylesheet">
    <link href="${contextPath}/resources/css/common.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <form method="POST" action="${contextPath}/forgot-password" class="form-signin">
        <h2 class="form-heading text-center">FORGOT PASSWORD</h2>
        <p class="text-center">Enter your username and registered email address.</p>

        <c:if test="${not empty message}">
            <div class="alert alert-info">${message}</div>
        </c:if>

        <input name="username" type="text" class="form-control" placeholder="Username" required/>
        <input name="email" type="email" class="form-control" placeholder="Registered Email" required/>

        <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}"/>

        <button class="btn btn-custom-LOGIN btn-lg btn-block" type="submit">SEND RESET LINK</button>
        <h4 class="text-center"><a href="${contextPath}/login">Back to Login</a></h4>
    </form>
</div>
</body>
</html>
