package com.visualpathit.account.controller;

import com.visualpathit.account.model.PasswordResetToken;
import com.visualpathit.account.model.User;
import com.visualpathit.account.repository.PasswordResetTokenRepository;
import com.visualpathit.account.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

@Controller
public class ForgotPasswordController {

    private static final Logger logger = LoggerFactory.getLogger(ForgotPasswordController.class);
    private static final int TOKEN_EXPIRY_MINUTES = 30;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordResetTokenRepository tokenRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    private JavaMailSender mailSender;

    @Value("${mail.enabled}")
    private boolean mailEnabled;

    @Value("${mail.username}")
    private String mailUsername;

    @Value("${mail.from}")
    private String mailFrom;

    @RequestMapping(value = "/forgot-password", method = RequestMethod.GET)
    public String forgotPasswordPage() {
        return "forgotPassword";
    }

    @RequestMapping(value = "/forgot-password", method = RequestMethod.POST)
    public String forgotPassword(@RequestParam("username") String username,
                                 @RequestParam("email") String email,
                                 HttpServletRequest request,
                                 Model model) {

        User user = userRepository.findByUsername(username);

        if (user != null && user.getUserEmail() != null
                && user.getUserEmail().equalsIgnoreCase(email.trim())) {

            PasswordResetToken existingToken = tokenRepository.findByUser(user);
            if (existingToken != null) {
                tokenRepository.delete(existingToken);
            }

            String tokenValue = UUID.randomUUID().toString();
            PasswordResetToken resetToken = new PasswordResetToken();
            resetToken.setToken(tokenValue);
            resetToken.setUser(user);

            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MINUTE, TOKEN_EXPIRY_MINUTES);
            resetToken.setExpiryDate(calendar.getTime());
            tokenRepository.save(resetToken);

            String resetLink = createResetLink(request, tokenValue);

            if (mailEnabled) {
                try {
                    sendResetEmail(user.getUserEmail(), resetLink);
                } catch (Exception e) {
                    logger.error("Unable to send password reset email", e);
                }
            } else {
                logger.info("MAIL DISABLED - Password reset link for {}: {}", username, resetLink);
            }
        }

        // Keep this response generic so the page does not reveal valid account details.
        model.addAttribute("message",
                "If the username and email match an account, a password reset link has been sent.");
        return "forgotPassword";
    }

    @RequestMapping(value = "/reset-password", method = RequestMethod.GET)
    public String resetPasswordPage(@RequestParam("token") String token, Model model) {
        PasswordResetToken resetToken = getValidToken(token);

        if (resetToken == null) {
            model.addAttribute("error", "This password reset link is invalid or has expired.");
            return "resetPassword";
        }

        model.addAttribute("token", token);
        return "resetPassword";
    }

    @RequestMapping(value = "/reset-password", method = RequestMethod.POST)
    public String resetPassword(@RequestParam("token") String token,
                                @RequestParam("password") String password,
                                @RequestParam("confirmPassword") String confirmPassword,
                                Model model) {

        if (password == null || password.length() < 8 || password.length() > 32) {
            model.addAttribute("error", "Password must be between 8 and 32 characters.");
            model.addAttribute("token", token);
            return "resetPassword";
        }

        if (!password.equals(confirmPassword)) {
            model.addAttribute("error", "Password and confirm password do not match.");
            model.addAttribute("token", token);
            return "resetPassword";
        }

        PasswordResetToken resetToken = getValidToken(token);
        if (resetToken == null) {
            model.addAttribute("error", "This password reset link is invalid or has expired.");
            return "resetPassword";
        }

        User user = resetToken.getUser();
        user.setPassword(bCryptPasswordEncoder.encode(password));
        userRepository.save(user);

        // A reset token is one-time use.
        tokenRepository.delete(resetToken);

        model.addAttribute("message", "Password changed successfully. Please login with your new password.");
        return "login";
    }

    private PasswordResetToken getValidToken(String token) {
        if (token == null || token.trim().isEmpty()) {
            return null;
        }

        PasswordResetToken resetToken = tokenRepository.findByToken(token);
        if (resetToken == null) {
            return null;
        }

        if (resetToken.getExpiryDate().before(new Date())) {
            tokenRepository.delete(resetToken);
            return null;
        }

        return resetToken;
    }

    private void sendResetEmail(String email, String resetLink) {
        SimpleMailMessage message = new SimpleMailMessage();
        String from = mailFrom == null || mailFrom.trim().isEmpty() ? mailUsername : mailFrom;
        if (from != null && !from.trim().isEmpty()) {
            message.setFrom(from);
        }
        message.setTo(email);
        message.setSubject("Reset your password");
        message.setText("A password reset was requested for your account.\n\n"
                + "Use this link within " + TOKEN_EXPIRY_MINUTES + " minutes:\n"
                + resetLink + "\n\n"
                + "If you did not request this change, ignore this email.");
        mailSender.send(message);
    }

    private String createResetLink(HttpServletRequest request, String token) {
        String scheme = request.getScheme();
        int port = request.getServerPort();
        boolean defaultPort = ("http".equalsIgnoreCase(scheme) && port == 80)
                || ("https".equalsIgnoreCase(scheme) && port == 443);

        return scheme + "://" + request.getServerName()
                + (defaultPort ? "" : ":" + port)
                + request.getContextPath()
                + "/reset-password?token=" + token;
    }
}
