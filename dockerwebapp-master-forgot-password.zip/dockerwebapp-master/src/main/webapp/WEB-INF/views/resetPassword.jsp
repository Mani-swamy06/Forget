<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset Password</title>
    <link href="${contextPath}/resources/css/bootstrap.min.css" rel="stylesheet">
    <link href="${contextPath}/resources/css/common.css" rel="stylesheet">
</head>
<body>
<div class="container">
    <form method="POST" action="${contextPath}/reset-password" class="form-signin">
        <h2 class="form-heading text-center">RESET PASSWORD</h2>

        <c:if test="${not empty error}">
            <div class="alert alert-danger">${error}</div>
        </c:if>

        <c:if test="${empty error || not empty token}">
            <input type="hidden" name="token" value="${token}"/>
            <input name="password" type="password" class="form-control" placeholder="New Password" required/>
            <input name="confirmPassword" type="password" class="form-control" placeholder="Confirm New Password" required/>
            <input type="hidden" name="${_csrf.parameterName}" value="${_csrf.token}"/>
            <button class="btn btn-custom-LOGIN btn-lg btn-block" type="submit">CHANGE PASSWORD</button>
        </c:if>

        <h4 class="text-center"><a href="${contextPath}/login">Back to Login</a></h4>
    </form>
</div>
</body>
</html>
